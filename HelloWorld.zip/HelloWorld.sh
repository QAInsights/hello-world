strMessage="Hello $USERNAME !"
echo $strMessage
echo "Executing Jenkins Build..."
echo "Waiting for 5 seconds"
sleep 5
echo "Shutting down in 3 seconds"
sleep 3